package com.itheima.know.utils;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.view.LayoutInflater;

public class ServiceManager {

	private static LayoutInflater inflater;
	private static Sensor accelerometerSensor;
    private static Sensor lightSensor;//光线传感器引用
    private static SensorManager sensorManager;
	
	private ServiceManager(){};
	
	public static LayoutInflater getLayoutInflater(Context context) {
		if (inflater == null) {
			synchronized(ServiceManager.class) {
				if (inflater == null) {
					inflater = LayoutInflater.from(context);
				}
			}
		}
		return inflater;
	}
	
	/**
     * 获得传感器管理器
     * @param context
     * @return
     */
    public static SensorManager getSensorManager(Context context) {
    	if (sensorManager == null) {
    		synchronized(ServiceManager.class) {
    			if (sensorManager == null) {
    				sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    			}
    		} 
    	}
    	return sensorManager;
    }
    /**
     * 获得加速管理器
     * @param context
     * @return
     */
    public static Sensor getAccelerometerSensor(Context context) {
    	if ( accelerometerSensor == null ){
    		synchronized(ServiceManager.class) {
    			if (accelerometerSensor == null) {
    				accelerometerSensor = getSensorManager(context).getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    			}
    		}
    	}
    	return accelerometerSensor;
    }
    public static Sensor getLightSensor(Context context) {
    	if ( lightSensor == null ){
    		synchronized(ServiceManager.class) {
    			if (lightSensor == null) {
    				lightSensor = getSensorManager(context).getDefaultSensor(Sensor.TYPE_LIGHT);
    			}
    		}
    	}
    	return lightSensor;
    }
	
}
